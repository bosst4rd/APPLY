# Schnellstart-Anleitung

## 1. Installation (5 Minuten)

```bash
# Repository klonen
git clone <repository-url>
cd APPLY
```

**Python installiert?**
- Falls nicht oder unsicher: Siehe [INSTALL_PYTHON.md](INSTALL_PYTHON.md) für detaillierte Anleitung
- Das Start-Skript prüft automatisch und gibt Hilfe!

## 2. Tool starten

**EMPFOHLEN - Mit automatischer Prüfung:**

**Linux/Mac:**
```bash
./start.sh
```

**Windows:**
```batch
start.bat
```

Das Start-Skript prüft automatisch alle Abhängigkeiten und gibt hilfreiche Fehlermeldungen!

**Alternativ - Direktstart:**

```bash
python3 main.py
```

Oder:

```bash
chmod +x main.py
./main.py
```

## 3. Erste Schritte

### Schritt 1: Beispieldatei laden
1. GUI öffnet sich automatisch
2. Klicken Sie auf **"Durchsuchen..."**
3. Wählen Sie `example_collect_data.json`
4. Klicken Sie auf **"Laden"**

### Schritt 2: Konfigurationen ansehen
- Die Liste zeigt alle verfügbaren Konfigurationen mit Checkboxen
- Kategorien mit Icons:
  - 🖥️ Hostname
  - 🌐 Netzwerk (LAN, WAN)
  - 📝 ALBIS-Registry (Datenbankpfad, Lizenz, Ports, etc.)
  - 👤 Benutzernamen
  - 📦 Installierte Software (mit Installationsoption)
  - ⚙️ Dienste
  - 📁 Dateien
- Alle Konfigurationen sind standardmäßig ausgewählt
- Scrollen Sie durch die Liste

### Schritt 3: Dry Run testen
1. Stellen Sie sicher, dass **"Dry Run"** aktiviert ist (Standard)
2. Klicken Sie auf **"Konfigurationen anwenden"**
3. Beobachten Sie den Log-Bereich
4. Sie sehen `[DRY RUN]` vor jedem Eintrag - nichts wird geändert!

### Schritt 4: Echte Migration (VORSICHT!)
⚠️ **NUR wenn Sie sicher sind!**

1. Erstellen Sie ein **Backup** Ihres Systems
2. Deaktivieren Sie **"Dry Run"**
3. Klicken Sie auf **"Konfigurationen anwenden"**
4. Bestätigen Sie die Sicherheitswarnung
5. Warten Sie bis die Migration abgeschlossen ist

## Häufige Verwendungsszenarien

### Szenario 1: Nur ALBIS-Registry wiederherstellen
1. Datei laden
2. "Alle abwählen" klicken
3. Nur Checkboxen unter "📝 ALBIS-Registry" aktivieren
4. "Konfigurationen anwenden"

### Szenario 2: Hostname und Netzwerk
1. Datei laden
2. "Alle abwählen" klicken
3. Checkboxen unter "🖥️ Hostname" und "🌐 Netzwerk" aktivieren
4. "Konfigurationen anwenden"

### Szenario 3: Nur Software-Liste anzeigen
1. Datei laden
2. "Alle abwählen" klicken
3. Checkboxen unter "📦 Installierte Software" aktivieren
4. Dry Run aktiviert lassen
5. "Konfigurationen anwenden" - Sie sehen welche Software installiert war

### Szenario 3: Eigene COLLECT-Datei
1. Erstellen Sie eine JSON-Datei im gleichen Format wie `example_collect_data.json`
2. Laden Sie Ihre Datei statt der Beispieldatei
3. Führen Sie zuerst einen Dry Run durch!

## Tipps

✅ **Immer zuerst Dry Run!**
✅ **Backup vor echter Migration!**
✅ **Logs überprüfen auf Fehler!**
✅ **Auf Test-System testen!**

❌ **Nie ohne Backup!**
❌ **Nie direkt auf Produktionssystem ohne Test!**
❌ **Nie Logs ignorieren!**

## Hilfe

Bei Problemen:
1. Überprüfen Sie die Logs im Tool
2. Lesen Sie `README.md` für Details
3. Erstellen Sie ein Issue im Repository

## GUI-Layout

Die GUI hat folgende Bereiche:
- **Oben**: Dateiauswahl mit "Durchsuchen" und "Laden"
- **Mitte**: Scrollbare Liste mit Checkboxen für jede Konfiguration
  - System-Information (nur Anzeige)
  - Kategorien mit Icons und Checkboxen
  - Beschreibungen für jedes Element
- **Buttons**: "Alle auswählen" / "Alle abwählen"
- **Optionen**: Dry Run Checkbox (Standard: aktiviert)
- **Button**: "Konfigurationen anwenden"
- **Fortschrittsbalken**: Zeigt den Fortschritt
- **Unten**: Log-Bereich mit allen Aktionen

## Was ist neu in Version 2.0?

✨ **Checkbox-Auswahl**: Jede Konfiguration hat ihre eigene Checkbox
📝 **ALBIS-Registry**: Vollständige Unterstützung für ALBIS Registry-Einträge
🖥️ **Hostname**: Hostname-Migration hinzugefügt
📦 **Software-Liste**: Installierte Software wird mit Installationsoption angezeigt
🎨 **Bessere UI**: Icons, Kategorien und Beschreibungen

Viel Erfolg! 🚀
