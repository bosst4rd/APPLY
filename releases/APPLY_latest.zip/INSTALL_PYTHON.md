# Python Installation Anleitung

Diese Anleitung hilft Ihnen bei der Installation von Python für das COLLECT Configuration Migration Tool.

## Voraussetzungen

- Python 3.7 oder höher
- tkinter (GUI-Bibliothek, normalerweise in Python enthalten)

---

## Windows Installation

### Schritt 1: Python herunterladen

1. Besuchen Sie: https://www.python.org/downloads/windows/
2. Klicken Sie auf "Download Python 3.x.x" (neueste stabile Version)
3. Laden Sie den "Windows installer (64-bit)" herunter

### Schritt 2: Python installieren

**WICHTIG - Diese Optionen MÜSSEN aktiviert werden:**

1. **Starten Sie den Installer**
2. **Aktivieren Sie diese Checkboxen:**
   - ✅ **"Add Python to PATH"** (ganz unten!)
   - ✅ **"Install launcher for all users"** (optional, aber empfohlen)

3. Klicken Sie auf **"Customize installation"**

4. **Optional Features - Aktivieren:**
   - ✅ Documentation
   - ✅ pip
   - ✅ **tcl/tk and IDLE** (WICHTIG für tkinter!)
   - ✅ Python test suite
   - ✅ py launcher

5. **Advanced Options - Aktivieren:**
   - ✅ Install for all users (empfohlen)
   - ✅ Associate files with Python
   - ✅ Create shortcuts for installed applications
   - ✅ **Add Python to environment variables** (WICHTIG!)
   - ✅ Precompile standard library

6. Klicken Sie auf **"Install"**

7. Warten Sie bis die Installation abgeschlossen ist

8. **Wichtig:** Starten Sie Ihren Computer NEU oder öffnen Sie ein NEUES Command Prompt

### Schritt 3: Installation überprüfen

Öffnen Sie ein **neues** Command Prompt (cmd.exe) und testen Sie:

```batch
python --version
```

Sollte anzeigen: `Python 3.x.x`

```batch
python -c "import tkinter; print('tkinter OK')"
```

Sollte anzeigen: `tkinter OK`

### Problemlösung (Windows)

**Problem: "python ist nicht als interner oder externer Befehl erkannt"**

Lösung:
1. Python wurde nicht zu PATH hinzugefügt
2. Deinstallieren Sie Python komplett
3. Installieren Sie neu und achten Sie auf "Add Python to PATH"!
4. Oder fügen Sie Python manuell zu PATH hinzu:
   - Suchen Sie nach "Umgebungsvariablen"
   - Bearbeiten Sie "Path"
   - Fügen Sie hinzu: `C:\Users\IhrName\AppData\Local\Programs\Python\Python3xx`

**Problem: "tkinter nicht gefunden"**

Lösung:
1. Python neu installieren
2. Beim "Customize installation" Schritt:
3. Aktivieren Sie "tcl/tk and IDLE"!

---

## Linux Installation

### Ubuntu / Debian

```bash
# Python und tkinter installieren
sudo apt-get update
sudo apt-get install python3 python3-tk python3-pip

# Version prüfen
python3 --version

# tkinter testen
python3 -c "import tkinter; print('tkinter OK')"
```

### Fedora / RHEL / CentOS

```bash
# Python und tkinter installieren
sudo dnf install python3 python3-tkinter python3-pip

# Version prüfen
python3 --version

# tkinter testen
python3 -c "import tkinter; print('tkinter OK')"
```

### Arch Linux / Manjaro

```bash
# Python und tkinter installieren
sudo pacman -S python python-tk

# Version prüfen
python3 --version

# tkinter testen
python3 -c "import tkinter; print('tkinter OK')"
```

### OpenSUSE

```bash
# Python und tkinter installieren
sudo zypper install python3 python3-tk

# Version prüfen
python3 --version

# tkinter testen
python3 -c "import tkinter; print('tkinter OK')"
```

---

## macOS Installation

### Option 1: Mit Homebrew (empfohlen)

```bash
# Homebrew installieren (falls nicht vorhanden)
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# Python installieren
brew install python3

# Version prüfen
python3 --version

# tkinter testen (sollte automatisch enthalten sein)
python3 -c "import tkinter; print('tkinter OK')"
```

### Option 2: Offizieller Installer

1. Besuchen Sie: https://www.python.org/downloads/macos/
2. Laden Sie den neuesten macOS installer herunter
3. Öffnen Sie die .pkg Datei
4. Folgen Sie den Installationsanweisungen
5. tkinter ist automatisch enthalten

---

## Nach der Installation

### Test des Migrations-Tools

1. Öffnen Sie ein **neues** Terminal/Command Prompt
2. Wechseln Sie in das APPLY-Verzeichnis:
   ```bash
   cd APPLY
   ```

3. **Windows:**
   ```batch
   start.bat
   ```

4. **Linux/Mac:**
   ```bash
   ./start.sh
   ```

Das Start-Skript wird automatisch alle Abhängigkeiten prüfen!

---

## Häufige Probleme

### "Command not found" oder "nicht erkannt"

**Ursache:** Python ist nicht im PATH

**Lösung:**
- **Windows:** Python neu installieren mit "Add to PATH" Option
- **Linux/Mac:** Stellen Sie sicher, dass Sie `python3` verwenden (nicht `python`)

### "tkinter not found"

**Ursache:** tkinter wurde nicht mit installiert

**Lösung:**
- **Windows:** Python neu installieren, "tcl/tk and IDLE" Option aktivieren
- **Linux:** Separates Paket installieren (siehe oben)
- **macOS:** tkinter sollte automatisch enthalten sein; ggf. Python neu installieren

### Alte Python-Version (< 3.7)

**Ursache:** System hat alte Python-Version

**Lösung:**
- Neueste Python-Version von python.org herunterladen
- Alte Version kann parallel installiert bleiben
- Nutzen Sie `python3` oder `py -3` zum Ausführen

### Nach Installation funktioniert es nicht

**Lösung:**
1. **Terminal/Command Prompt komplett schließen**
2. **Neues Terminal öffnen**
3. Erneut testen
4. Im Zweifel: Computer neu starten

---

## Hilfe & Support

Bei Problemen:

1. **Führen Sie das Start-Skript aus:**
   - Windows: `start.bat`
   - Linux/Mac: `./start.sh`

   Das Skript zeigt detaillierte Fehler und Lösungen an!

2. **Überprüfen Sie die Logs**

3. **Dokumentation lesen:**
   - README.md
   - QUICKSTART.md

4. **Python-Version prüfen:**
   ```bash
   python --version
   python3 --version
   py -3 --version  # Windows
   ```

5. **Alle Module testen:**
   ```bash
   python3 -c "import tkinter, json, os, subprocess, pathlib, typing, threading, platform; print('All OK!')"
   ```

---

## Zusammenfassung

**Checkliste für erfolgreiche Installation:**

- ✅ Python 3.7 oder höher installiert
- ✅ Python im PATH (Befehl `python` oder `python3` funktioniert)
- ✅ tkinter verfügbar
- ✅ Terminal neu geöffnet nach Installation
- ✅ Start-Skript erfolgreich ausgeführt
- ✅ GUI öffnet sich

Viel Erfolg! 🚀
