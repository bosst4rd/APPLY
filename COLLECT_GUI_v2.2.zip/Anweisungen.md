# eXpletus COLLECT - Anweisungen

## 📁 Dokumentation

| Datei | Beschreibung |
|-------|--------------|
| `docs/README.md` | Benutzer-Dokumentation (Installation, Bedienung) |
| `docs/FEATURES_STATUS.md` | Feature-Status, Roadmap, Changelog |

---

## 🚀 Schnellstart

**Einfach `start.bat` per Doppelklick starten!**

Das Skript macht alles automatisch:
1. ✅ Prüft ob Python installiert ist
2. ✅ Falls nicht: Lädt Python 3.11.9 herunter (~30 MB)
3. ✅ Installiert Python automatisch (silent, mit PATH)
4. ✅ Installiert Dependencies (customtkinter, Pillow)
5. ✅ Startet die GUI

---

## ✅ Version 2.1 (aktuell)

### Neue Features:
- **Anti-Loop-Schutz** - Laufwerks-Root (C:\, D:\) als Zielordner blockiert
- **Drucker verbessert** - IPv6 entfernt, Standarddrucker markiert
- **Netzwerk verbessert** - Nur aktive Adapter, nur IPv4-Adressen

### Bestehende Features:
- Moderne GUI (CustomTkinter, Dark-Theme)
- Automatische Python-Installation
- JSON-Export für APPLY-Tool
- Basis-Infos, Netzwerk, Drucker, Screenshot
- ALBIS-Dateien und Registry
- Benutzerordner (optional)

---

## 📋 Verzeichnisstruktur

```
COLLECT_GUI/
├── src/gui_collector.py    # Haupt-Anwendung
├── media/                  # Logos & Icons
├── docs/                   # Dokumentation
│   ├── README.md          # Benutzer-Doku
│   └── FEATURES_STATUS.md # Roadmap & Changelog
├── archive/               # Alte Versionen
├── start.bat              # ⭐ Haupt-Starter
├── start_debug.bat        # Debug-Modus
├── requirements.txt       # Dependencies
└── Anweisungen.md         # Diese Datei
```

---

## 🔗 Siehe auch

- **Feature-Status & Roadmap:** `docs/FEATURES_STATUS.md`
- **Benutzer-Dokumentation:** `docs/README.md`
