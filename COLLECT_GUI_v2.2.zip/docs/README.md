# System Information Collector - GUI

Eine moderne grafische Oberfläche für das System-Diagnose-Tool zum Sammeln von Systeminformationen.

## 🎯 Features

- **Moderne GUI**: Dunkles Design mit CustomTkinter
- **Flexibel**: Wählbare Sammlungs-Optionen
- **Live-Feedback**: Echtzeit-Fortschrittsanzeige und Log
- **Benutzerfreundlich**: Intuitive Bedienung

## 📋 Gesammelte Informationen

- ✅ **Basis-Informationen**: Computername, Benutzer, Seriennummer, Datum/Zeit
- ✅ **Drucker-Liste**: Installierte Drucker (gefiltert, ohne Fax/PDF-Drucker)
- ✅ **Netzwerk-Informationen**: IP-Adressen, DNS, Gateway, Netzwerkadapter
- ✅ **Registry-Export**: HKCU\Software\ALBIS
- ✅ **ALBIS-Dateien**: Kopiert Dateien aus C:\CGM\ALBISWIN
- ⚠️ **Benutzerordner**: Desktop, Dokumente, Bilder (optional, kann groß sein!)
- ✅ **Desktop-Screenshot**: PNG-Screenshot des Desktops

## 🚀 Installation & Verwendung

### Voraussetzungen

- Windows 10/11
- Internetverbindung (nur beim ersten Start)

### Schnellstart - Vollautomatisch! 🚀

**Einfach `start.bat` per Doppelklick starten - fertig!**

Das Skript macht **alles automatisch**:
- ✅ Prüft ob Python installiert ist
- ✅ **Installiert Python automatisch**, falls nicht vorhanden (ca. 30 MB Download)
- ✅ Installiert alle benötigten Pakete automatisch
- ✅ Startet die GUI

**Keine manuelle Installation nötig!** Das Skript kümmert sich um alles.

**Wichtig:** Nach der automatischen Python-Installation startet das Skript sich automatisch neu. Beim zweiten Start wird dann die GUI gestartet.

### GUI-Test (Optional)

Falls die GUI nicht startet oder Probleme zeigt:

```bash
python test_gui.py
```

Dieser Test zeigt, ob CustomTkinter korrekt funktioniert und ein einfaches Fenster angezeigt wird.

### Manuelle Verwendung (optional)

Falls Sie das Programm direkt starten möchten:

```bash
pip install -r requirements.txt  # Nur beim ersten Mal
python gui_collector.py
```

## 📖 Anleitung

1. **Zielordner wählen**: Klicken Sie auf "Durchsuchen" und wählen Sie den Zielordner
   - Ein Unterordner mit dem Computernamen wird automatisch erstellt

2. **Optionen wählen**: Aktivieren/Deaktivieren Sie die gewünschten Sammlungs-Optionen
   - Standardmäßig sind alle außer "Benutzerordner" aktiviert
   - Benutzerordner können sehr groß sein!

3. **Sammlung starten**: Klicken Sie auf "▶ Sammlung starten"
   - Der Fortschritt wird in Echtzeit angezeigt
   - Das Log zeigt Details zu jedem Schritt

4. **Ergebnis**: Nach Abschluss öffnet sich automatisch der Zielordner im Explorer

## 📁 Ausgabe-Struktur

```
<Zielordner>/<COMPUTERNAME>/
├── Basisinfo.txt              # Basis-Systeminformationen
├── Drucker.txt                # Druckerliste
├── Netzwerk.txt               # Netzwerk-Konfiguration
├── albis.reg                  # Registry-Export
├── desktop.png                # Desktop-Screenshot
├── ALBISWIN/                  # ALBIS-Dateien
│   └── ...
└── (optional)
    ├── Dokumente/
    ├── Bilder/
    └── Desktop/
```

## ⚙️ Technische Details

- **GUI-Framework**: CustomTkinter (moderne tkinter-Erweiterung)
- **Backend**: PowerShell-Scripts für Windows-spezifische Operationen
- **Threading**: Asynchrone Ausführung für reaktive GUI

## 🔧 Troubleshooting

### "Download fehlgeschlagen"
- Prüfen Sie Ihre Internetverbindung
- Stellen Sie sicher, dass keine Firewall den Download blockiert
- Versuchen Sie es erneut - manchmal hilft ein zweiter Versuch

### "Installation der Dependencies fehlgeschlagen"
- Prüfen Sie Ihre Internetverbindung
- Stellen Sie sicher, dass keine Firewall pip blockiert
- Starten Sie `start.bat` erneut

### "Python wurde installiert, aber nicht im PATH gefunden"
- Das Skript startet sich automatisch neu
- Falls nicht: Starten Sie `start.bat` manuell erneut

### "Skript schließt sich sofort"
- Prüfen Sie, ob Python korrekt installiert wurde
- Führen Sie `start.bat` erneut aus
- Das Skript startet sich nach Python-Installation automatisch neu

### "GUI zeigt keine Buttons oder Optionen"
- Führen Sie `python test_gui.py` aus, um die Installation zu testen
- Wenn der Test funktioniert, aber die Hauptanwendung nicht: Melden Sie den Fehler
- Prüfen Sie, ob CustomTkinter korrekt installiert ist: `pip install --upgrade customtkinter`

### "Registry-Export fehlgeschlagen"
- Nur relevant wenn ALBIS installiert ist
- Der Fehler kann ignoriert werden, wenn ALBIS nicht verwendet wird

### "ALBIS-Pfad nicht gefunden"
- Normal, wenn ALBIS nicht unter C:\CGM\ALBISWIN installiert ist
- Kann ignoriert werden

## 📝 Changelog

### Version 1.0 (2025)
- Initiale Version mit moderner GUI
- Alle Funktionen des Original-PowerShell-Skripts
- Live-Fortschrittsanzeige
- Flexible Sammlungs-Optionen

## 📄 Lizenz

Internes Tool für Diagnose- und Support-Zwecke.

## 🤝 Support

Bei Problemen oder Fragen wenden Sie sich an Ihren IT-Support.
