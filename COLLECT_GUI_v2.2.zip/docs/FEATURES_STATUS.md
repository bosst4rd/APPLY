# eXpletus COLLECT - Feature Status & Roadmap

## 🎯 Ablauf-Logik
- [ ] **Phase 1: START-CHECK** (alle Scans/Checks vor Auswahl)
- [ ] **Phase 2: Auswahl** (Checkboxen werden aktiviert basierend auf Scan-Ergebnissen)
- [ ] **Phase 3: Ausführung** (entweder sofort oder gesammelt am Ende)
- [x] **Anti-Loop-Schutz** (C:\ als Zielordner blockieren) ✅ v2.1

---

## ✅ BEREITS IMPLEMENTIERT

### Grundfunktionen
- [x] **Zielordner wählen** (FolderBrowserDialog, Desktop als Default)
- [x] **Hostname-basierte Ordner** (COMPUTERNAME als Unterordner)
- [x] **Logging** (Echtzeit-Log in GUI)
- [x] **Fortschrittsanzeige** (Progressbar + Status)
- [x] **Anti-Loop-Schutz** (Laufwerks-Root blockiert) ✅ v2.1
- [x] **Automatische Python-Installation** (start.bat)
- [x] **JSON-Export für APPLY-Tool** (migration.json)

### RUBRIK: ALBIS
- [x] **ALBISWIN Dateien** (nur Files, keine Ordner aus C:\CGM\ALBISWIN)
- [x] **ALBIS Registry** (HKCU\Software\ALBIS → albis.reg)

### RUBRIK: EIGENE DATEN
- [x] **Benutzerordner** (Desktop, Dokumente, Bilder - optional per Checkbox)
- [ ] Mailkonto-Erkennung
- [ ] MS Office Erkennung
- [ ] Browser-Favoriten Export

### RUBRIK: SYSTEMINFOS
- [x] **Basis-Informationen** (Datum, Computername, Username, Domain, Seriennummer)
- [x] **Netzwerk** (nur aktive Adapter, IPv4 only, ohne IPv6) ✅ v2.1
- [x] **Drucker** (mit Blacklist, Standarddrucker markiert, ohne IPv6) ✅ v2.1
- [x] **Screenshot** (Desktop)

### RUBRIK: SOFTWARE
- [ ] CGM-Software-Scan
- [ ] Externe Software-Scan (Whitelist)
- [ ] Autostart-Analyse
- [ ] Aufgabenplanung-Export

### RUBRIK: WEITERE OPTIONEN
- [ ] Drivesnapshot Integration

---

## ✅ BEHOBENE PROBLEME (v2.1)

### Anti-Loop
- [x] **Anti-Loop-Schutz implementiert** - Laufwerks-Root (C:\, D:\, etc.) wird blockiert

### Drucker
- [x] **IPv6 wird nicht mehr angezeigt** - Netzwerkdrucker werden bereinigt
- [x] Blacklist vorhanden (Fax, XPS, PDF, OneNote)
- [x] Deduplizierung funktioniert
- [x] **Standarddrucker wird gekennzeichnet** (*** STANDARD ***)

### Netzwerk
- [x] **IPv6 ausgeblendet** - Nur IPv4-Adressen werden angezeigt
- [x] **Nur aktive Adapter** - Inaktive Adapter werden nicht mehr gelistet
- [x] DNS-Server nur IPv4

### Benutzerordner
- [x] Optional per Checkbox (funktioniert)
- [ ] **Keine Größenbeschränkung** (kann problematisch werden)

---

## 📋 PRIORITY 1 - NÄCHSTE SCHRITTE

### 1. Start-Check implementieren
- [ ] ALBISWIN-Pfad-Check (automatisch deaktivieren wenn nicht vorhanden)
- [ ] Registry-Check
- [ ] Netzwerk-Adapter-Check
- [ ] Mail-Client-Check
- [ ] Office-Check

### 2. Größenbeschränkung Benutzerordner
- [ ] Warnung bei großen Ordnern (>500MB)
- [ ] Optional: Größenlimit einstellbar

---

## 📋 PRIORITY 2 - ERWEITERTE FEATURES

### Software-Erkennung
- [ ] CGM-Software Whitelist (DMP-Assist, PraxisArchiv, Praxistimer, Clickdoc, Organizer)
- [ ] Externe Software Whitelist (Medizin, Finanzen)
- [ ] Versionsnummern erfassen

### Mail & Office
- [ ] Mail-Client Erkennung (Outlook, Thunderbird)
- [ ] MS Office Produktinfo (keine Light-Versionen)
- [ ] MoBackup Integration (externe .exe)

### Browser
- [ ] Standard-Browser ermitteln
- [ ] Favoriten/Lesezeichen Export
- [ ] Passwörter (falls möglich)

---

## 📋 PRIORITY 3 - ZUSÄTZLICHE FUNKTIONEN

### Autostart & Aufgaben
- [ ] Autostart-Programme erfassen
- [ ] Autostart-Dateien kopieren
- [ ] Benutzerdefinierte Tasks (Windows Aufgabenplanung)

### Peripherie
- [ ] Scanner-Erkennung
- [ ] Weitere Komponenten

### Externe Tools
- [ ] Drivesnapshot Integration
- [ ] MoBackup Integration

---

## 📚 WHITELISTS (zu erstellen)

- [ ] **wl_cgm-sw.txt** (CGM Software: DMP-Assist, PraxisArchiv, Praxistimer, Clickdoc, Organizer)
- [ ] **wl_medizin-sw.txt** (Medizinische Software: Boso, Snconnector, Infobox, Getsend, EKG-Software)
- [ ] **wl_finanz-sw.txt** (Finanzsoftware)
- [ ] **wl_extern-sw.txt** (Sonstige häufige Software)

---

## 🔧 EXTERNE SOFTWARE (benötigt)

### Integration notwendig
- **MoBackup** (mobackup.exe) - Outlook Backup Tool
  - Pfad: `\root\sw\mobackup\`
  - Separates Fenster oder eingebettet?

- **Drivesnapshot** (snapshot.exe) - Laufwerkssicherung
  - Pfad: `\root\sw\snapshot\`
  - Kommandozeilen-Integration
  - Anleitung: `manu_snapshot.txt` in `\root\docs\`

---

## 📝 Changelog

### Version 2.1 (2025-11-22)
- ✅ Anti-Loop-Schutz: Laufwerks-Root als Zielordner blockiert
- ✅ Drucker: IPv6 entfernt, Standarddrucker markiert
- ✅ Netzwerk: Nur aktive Adapter, nur IPv4

### Version 2.0 (2025-11-17)
- ✅ Moderne GUI mit CustomTkinter
- ✅ Automatische Python-Installation
- ✅ JSON-Export für APPLY-Tool
- ✅ Logo-Support
- ✅ Beenden-Button
