# Media Dateien

## Logo

Bitte legen Sie hier das Logo ab:

- **logo.png** - Hauptlogo (256x256 px, PNG)
- **icon.ico** - Icon für Titelleiste (32x32 px, ICO oder PNG)

### Format:
- PNG mit transparentem Hintergrund bevorzugt
- Empfohlene Größen:
  - Logo: 256x256 px (wird automatisch skaliert)
  - Icon: 32x32 px oder 64x64 px

### Verwendung:
- Logo wird im GUI-Header angezeigt
- Icon wird in der Fenster-Titelleiste verwendet
