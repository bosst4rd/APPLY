#!/usr/bin/env python3
"""Erstellt ein Logo-Placeholder"""

from PIL import Image, ImageDraw, ImageFont

# Logo erstellen (256x256)
img = Image.new('RGB', (256, 256), color='#1a1a1a')
draw = ImageDraw.Draw(img)

# Kreis zeichnen
draw.ellipse([40, 40, 216, 216], fill='#2fa572', outline='#28a745', width=4)

# Text
try:
    font_large = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 60)
    font_small = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 24)
except:
    font_large = ImageFont.load_default()
    font_small = ImageFont.load_default()

# Großes "C"
draw.text((100, 80), "C", fill='white', font=font_large, anchor="mm")

# "Collector"
draw.text((128, 160), "Collector", fill='white', font=font_small, anchor="mm")

# Speichern
img.save('/home/user/COLLECT_GUI/media/logo.png')
print("Logo erstellt: media/logo.png")

# Auch kleines Icon für Titlebar
icon = img.resize((32, 32), Image.Resampling.LANCZOS)
icon.save('/home/user/COLLECT_GUI/media/icon.png')
print("Icon erstellt: media/icon.png")
