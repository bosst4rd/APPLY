#!/usr/bin/env python3
"""
eXpletus COLLECT - Modern GUI
Version 2.0 - Mit JSON-Export und erweiterter Funktionalität
"""

import customtkinter as ctk
import tkinter as tk
from tkinter import filedialog
from PIL import Image
import subprocess
import os
import sys
import threading
import json
from datetime import datetime
from pathlib import Path

# Konfiguration
ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")


class CollectorGUI(ctk.CTk):
    def __init__(self):
        super().__init__()

        # Fenster-Konfiguration
        self.title("eXpletus COLLECT v2.2")
        self.geometry("850x500")
        self.minsize(800, 450)

        # Logo setzen (falls vorhanden)
        try:
            logo_path = Path(__file__).parent.parent / "media" / "expletus_1.png"
            if logo_path.exists():
                self.iconphoto(True, tk.PhotoImage(file=str(logo_path)))
        except:
            pass  # Kein Logo verfügbar

        # Variablen
        self.is_running = False
        self.output_folder = tk.StringVar(value=str(Path.home() / "Desktop"))

        # Sammlungs-Optionen - Spalte 1 (Bestehend)
        self.collect_baseinfo = tk.BooleanVar(value=True)
        self.collect_printers = tk.BooleanVar(value=True)
        self.collect_network = tk.BooleanVar(value=True)
        self.collect_registry = tk.BooleanVar(value=True)
        self.collect_albis = tk.BooleanVar(value=True)
        self.collect_userfolders = tk.BooleanVar(value=False)
        self.collect_screenshot = tk.BooleanVar(value=True)

        # Sammlungs-Optionen - Spalte 2 (Neu)
        self.collect_mail = tk.BooleanVar(value=True)
        self.collect_office = tk.BooleanVar(value=True)
        self.collect_browser = tk.BooleanVar(value=True)
        self.collect_autostart = tk.BooleanVar(value=True)
        self.collect_software = tk.BooleanVar(value=True)
        self.collect_tasks = tk.BooleanVar(value=False)

        # JSON-Export Option
        self.export_json = tk.BooleanVar(value=False)

        # Gesammelte Daten für JSON
        self.collected_data = {}

        self.create_ui()

    def create_ui(self):
        """Erstellt die Benutzeroberfläche (kompakt, ohne Scrollen)"""

        # === HEADER (Logo + Titel + Zielordner in einer Zeile) ===
        header_frame = ctk.CTkFrame(self, fg_color="transparent")
        header_frame.pack(fill="x", padx=10, pady=(10, 5))

        # Logo links
        try:
            logo_path = Path(__file__).parent.parent / "media" / "expletus_1.png"
            if logo_path.exists():
                logo_img = Image.open(logo_path)
                logo_img = logo_img.resize((48, 48), Image.Resampling.LANCZOS)
                self.logo_ctk = ctk.CTkImage(light_image=logo_img, dark_image=logo_img, size=(48, 48))
                ctk.CTkLabel(header_frame, image=self.logo_ctk, text="").pack(side="left", padx=(0, 10))
        except:
            pass

        # Titel
        title_frame = ctk.CTkFrame(header_frame, fg_color="transparent")
        title_frame.pack(side="left", fill="x", expand=True)
        ctk.CTkLabel(title_frame, text="eXpletus COLLECT", font=("Arial", 18, "bold")).pack(anchor="w")
        ctk.CTkLabel(title_frame, text="System-Diagnose v2.2", font=("Arial", 9), text_color="gray").pack(anchor="w")

        # Zielordner rechts
        folder_frame = ctk.CTkFrame(header_frame, fg_color="transparent")
        folder_frame.pack(side="right")
        ctk.CTkLabel(folder_frame, text="Zielordner:", font=("Arial", 10)).pack(anchor="e")
        folder_row = ctk.CTkFrame(folder_frame, fg_color="transparent")
        folder_row.pack()
        self.folder_entry = ctk.CTkEntry(folder_row, textvariable=self.output_folder, width=250, height=28, font=("Arial", 9))
        self.folder_entry.pack(side="left", padx=(0, 5))
        ctk.CTkButton(folder_row, text="...", command=self.select_folder, width=30, height=28).pack(side="left")

        # === OPTIONEN (3 Spalten) ===
        options_frame = ctk.CTkFrame(self)
        options_frame.pack(fill="x", padx=10, pady=5)

        # 2-Spalten-Container
        columns_frame = ctk.CTkFrame(options_frame, fg_color="transparent")
        columns_frame.pack(fill="x", padx=10, pady=(0, 10))
        columns_frame.grid_columnconfigure(0, weight=1)
        columns_frame.grid_columnconfigure(1, weight=1)

        # Spalte 1: System & ALBIS
        col1 = ctk.CTkFrame(columns_frame)
        col1.grid(row=0, column=0, sticky="nsew", padx=(0, 5))

        ctk.CTkLabel(col1, text="📊 System & ALBIS", font=("Arial", 11, "bold")).pack(anchor="w", padx=8, pady=(8, 5))

        options_col1 = [
            (self.collect_baseinfo, "Basis-Infos", "PC, User, SN"),
            (self.collect_printers, "Drucker", "gefiltert"),
            (self.collect_network, "Netzwerk", "IP, DNS, Gateway"),
            (self.collect_registry, "ALBIS Registry", "HKCU"),
            (self.collect_albis, "ALBIS Dateien", "ALBISWIN"),
            (self.collect_userfolders, "Benutzerordner", "Desktop, Docs"),
            (self.collect_screenshot, "Screenshot", "Desktop PNG"),
        ]

        for var, title, desc in options_col1:
            cb = ctk.CTkCheckBox(col1, text=f"{title} ({desc})", variable=var, font=("Arial", 10))
            cb.pack(anchor="w", padx=8, pady=2)

        # Spalte 2: Neue Features
        col2 = ctk.CTkFrame(columns_frame)
        col2.grid(row=0, column=1, sticky="nsew", padx=(5, 0))

        ctk.CTkLabel(col2, text="🔍 Software & Daten", font=("Arial", 11, "bold")).pack(anchor="w", padx=8, pady=(8, 5))

        options_col2 = [
            (self.collect_mail, "E-Mail", "Outlook, Thunderbird"),
            (self.collect_office, "MS Office", "Version & Lizenz"),
            (self.collect_browser, "Browser", "Favoriten"),
            (self.collect_autostart, "Autostart", "Programme"),
            (self.collect_software, "Software", "CGM, Medizin"),
            (self.collect_tasks, "Aufgabenplanung", "Tasks"),
        ]

        for var, title, desc in options_col2:
            cb = ctk.CTkCheckBox(col2, text=f"{title} ({desc})", variable=var, font=("Arial", 10))
            cb.pack(anchor="w", padx=8, pady=2)

        # JSON-Export als Checkbox in Spalte 2
        json_cb = ctk.CTkCheckBox(col2, text="JSON für APPLY-Tool", variable=self.export_json, font=("Arial", 10), text_color="#2fa572")
        json_cb.pack(anchor="w", padx=8, pady=(8, 2))

        # === STATUS & LOG (kompakt) ===
        status_frame = ctk.CTkFrame(self)
        status_frame.pack(fill="both", expand=True, padx=10, pady=5)

        # Progressbar und Status in einer Zeile
        progress_row = ctk.CTkFrame(status_frame, fg_color="transparent")
        progress_row.pack(fill="x", padx=10, pady=5)

        self.progress_bar = ctk.CTkProgressBar(progress_row, width=300)
        self.progress_bar.pack(side="left", padx=(0, 10))
        self.progress_bar.set(0)

        self.status_label = ctk.CTkLabel(progress_row, text="Bereit", font=("Arial", 10))
        self.status_label.pack(side="left")

        self.log_text = ctk.CTkTextbox(status_frame, height=120, font=("Consolas", 9))
        self.log_text.pack(fill="both", expand=True, padx=10, pady=(0, 5))

        # === BUTTONS - WICHTIG: Feste Position am unteren Rand ===
        # Buttons AUSSERHALB des Scroll-Bereichs für dauerhafte Sichtbarkeit
        button_frame = ctk.CTkFrame(self)
        button_frame.pack(fill="x", side="bottom", padx=10, pady=10)

        self.start_btn = ctk.CTkButton(
            button_frame,
            text="▶ SAMMLUNG STARTEN",
            command=self.start_collection,
            height=45,
            font=("Arial", 13, "bold"),
            fg_color="#28a745",
            hover_color="#218838"
        )
        self.start_btn.pack(side="left", fill="x", expand=True, padx=(0, 5))

        self.stop_btn = ctk.CTkButton(
            button_frame,
            text="⏹ ABBRECHEN",
            command=self.stop_collection,
            height=45,
            font=("Arial", 13, "bold"),
            fg_color="#dc3545",
            hover_color="#c82333",
            state="disabled"
        )
        self.stop_btn.pack(side="left", fill="x", expand=True, padx=5)

        self.clear_btn = ctk.CTkButton(
            button_frame,
            text="🗑 LOG",
            command=self.clear_log,
            height=45,
            font=("Arial", 11),
            fg_color="gray",
            hover_color="darkgray",
            width=80
        )
        self.clear_btn.pack(side="right", padx=(5, 0))

        self.exit_btn = ctk.CTkButton(
            button_frame,
            text="✖ BEENDEN",
            command=self.exit_application,
            height=45,
            font=("Arial", 11),
            fg_color="gray30",
            hover_color="gray20",
            width=90
        )
        self.exit_btn.pack(side="right", padx=(5, 0))

        # Willkommensnachricht
        self.log("=== eXpletus COLLECT v2.2 ===")
        self.log(f"Zielordner: {self.output_folder.get()}")
        self.log("Bereit zum Starten!")

    def log(self, message):
        """Fügt Nachricht zum Log hinzu"""
        timestamp = datetime.now().strftime("%H:%M:%S")
        self.log_text.insert("end", f"[{timestamp}] {message}\n")
        self.log_text.see("end")

    def clear_log(self):
        """Löscht das Log"""
        self.log_text.delete("1.0", "end")

    def exit_application(self):
        """Beendet die Anwendung"""
        if self.is_running:
            from tkinter import messagebox
            result = messagebox.askyesno(
                "Sammlung läuft",
                "Eine Sammlung läuft gerade. Wirklich beenden?"
            )
            if not result:
                return

        self.log("Anwendung wird beendet...")
        self.quit()
        self.destroy()

    def select_folder(self):
        """Ordner auswählen"""
        current = self.output_folder.get()
        self.log(f"Öffne Ordner-Dialog... (aktuell: {current})")

        folder = filedialog.askdirectory(
            initialdir=current if current else str(Path.home()),
            title="Zielordner wählen"
        )

        if folder:
            # Nur StringVar setzen - Entry wird automatisch aktualisiert
            self.output_folder.set(folder)
            self.log(f"✓ Zielordner gewählt: {folder}")
            self.log(f"  Variable enthält jetzt: '{self.output_folder.get()}'")
        else:
            self.log("Ordner-Auswahl abgebrochen")

    def start_collection(self):
        """Startet Sammlung"""
        if self.is_running:
            return

        # Zielordner aus Entry-Feld holen (falls manuell geändert)
        entry_value = self.folder_entry.get()
        if entry_value and entry_value.strip():
            self.output_folder.set(entry_value)

        # Zielordner validieren
        target_folder = self.output_folder.get()
        self.log(f"Prüfe Zielordner: '{target_folder}'")
        self.log(f"  Entry-Feld enthält: '{entry_value}'")

        if not target_folder or target_folder.strip() == "":
            self.log("✗ FEHLER: Kein Zielordner gewählt!")
            from tkinter import messagebox
            messagebox.showerror(
                "Fehler",
                "Bitte wählen Sie einen Zielordner aus!\n\nKlicken Sie auf 'Durchsuchen...' um einen Ordner zu wählen."
            )
            return

        # Prüfen ob Zielordner existiert oder erstellt werden kann
        try:
            target_path = Path(target_folder)
            target_str = str(target_path).lower().replace('/', '\\')

            # Anti-Loop-Schutz: Laufwerks-Root blockieren (C:\, D:\, etc.)
            if target_path.parent == target_path or str(target_path).rstrip('\\/ ').endswith(':'):
                self.log("✗ FEHLER: Laufwerks-Root als Zielordner nicht erlaubt!")
                from tkinter import messagebox
                messagebox.showerror(
                    "Ungültiger Zielordner",
                    "Das Laufwerks-Root (z.B. C:\\) kann nicht als Zielordner verwendet werden!"
                )
                return

            # Anti-Loop: Benutzerordner als Ziel blockieren
            blocked_paths = [
                os.path.expanduser("~\\Desktop").lower(),
                os.path.expanduser("~\\Documents").lower(),
                os.path.expanduser("~\\Dokumente").lower(),
                os.path.expanduser("~\\Pictures").lower(),
                os.path.expanduser("~\\Bilder").lower(),
                os.path.expanduser("~").lower(),
                os.environ.get('USERPROFILE', '').lower(),
            ]

            for blocked in blocked_paths:
                if blocked and (target_str == blocked.replace('/', '\\') or
                               target_str.rstrip('\\') == blocked.replace('/', '\\').rstrip('\\')):
                    self.log(f"✗ FEHLER: Benutzerordner als Ziel nicht erlaubt: {target_folder}")
                    from tkinter import messagebox
                    messagebox.showerror(
                        "Ungültiger Zielordner",
                        f"Benutzerordner können nicht als Zielordner verwendet werden!\n\n"
                        f"Gesperrt: {target_folder}\n\n"
                        f"Bitte wählen Sie einen anderen Ordner, z.B.:\n"
                        f"• C:\\Sammlung\n"
                        f"• D:\\Backup"
                    )
                    return

            if not target_path.exists():
                target_path.mkdir(parents=True, exist_ok=True)
            if not target_path.is_dir():
                self.log("✗ FEHLER: Zielordner ist kein Verzeichnis!")
                from tkinter import messagebox
                messagebox.showerror(
                    "Fehler",
                    f"'{target_folder}' ist kein gültiges Verzeichnis!"
                )
                return
        except Exception as e:
            self.log(f"✗ FEHLER: Zielordner ungültig: {e}")
            from tkinter import messagebox
            messagebox.showerror(
                "Fehler",
                f"Zielordner ist ungültig:\n{e}"
            )
            return

        self.is_running = True
        self.start_btn.configure(state="disabled")
        self.stop_btn.configure(state="normal")

        thread = threading.Thread(target=self.run_collection, daemon=True)
        thread.start()

    def stop_collection(self):
        """Stoppt Sammlung"""
        self.is_running = False
        self.log("⚠ Sammlung wird abgebrochen...")

    def update_progress(self, value, text):
        """Aktualisiert Fortschritt"""
        self.progress_bar.set(value)
        self.status_label.configure(text=text)

    def run_collection(self):
        """Führt Sammlung durch"""
        try:
            self.log("=== Sammlung gestartet ===")

            # Zielordner erstellen
            hostname = os.environ.get('COMPUTERNAME', 'UNKNOWN')
            dest_root = Path(self.output_folder.get()) / hostname
            dest_root.mkdir(parents=True, exist_ok=True)
            self.log(f"✓ Zielordner: {dest_root}")

            # Schritte sammeln
            steps = []
            if self.collect_baseinfo.get():
                steps.append(("Basis-Informationen", self.collect_base_info))
            if self.collect_printers.get():
                steps.append(("Drucker-Liste", self.collect_printers_info))
            if self.collect_network.get():
                steps.append(("Netzwerk-Informationen", self.collect_network_info))
            if self.collect_registry.get():
                steps.append(("Registry-Export", self.collect_registry_export))
            if self.collect_albis.get():
                steps.append(("ALBIS-Dateien", self.collect_albis_files))
            if self.collect_userfolders.get():
                steps.append(("Benutzerordner", self.collect_user_folders))
            if self.collect_screenshot.get():
                steps.append(("Screenshot", self.collect_screenshot_image))

            # Neue Features (Spalte 2)
            if self.collect_mail.get():
                steps.append(("E-Mail-Clients", self.collect_mail_info))
            if self.collect_office.get():
                steps.append(("MS Office", self.collect_office_info))
            if self.collect_browser.get():
                steps.append(("Browser-Favoriten", self.collect_browser_favorites))
            if self.collect_autostart.get():
                steps.append(("Autostart-Programme", self.collect_autostart_info))
            if self.collect_software.get():
                steps.append(("Software-Scan", self.collect_software_info))
            if self.collect_tasks.get():
                steps.append(("Aufgabenplanung", self.collect_scheduled_tasks))

            total = len(steps)

            # Schritte ausführen
            for i, (name, func) in enumerate(steps):
                if not self.is_running:
                    break

                progress = (i + 1) / total
                self.update_progress(progress, f"{name}... ({i+1}/{total})")
                self.log(f"→ {name}...")

                try:
                    func(dest_root)
                    self.log(f"  ✓ {name} abgeschlossen")
                except Exception as e:
                    self.log(f"  ✗ Fehler: {str(e)}")

            if self.is_running:
                # Übersichtsdatei erstellen (immer)
                self.log("→ Erstelle Übersichtsdatei...")
                try:
                    self.create_overview(dest_root)
                    self.log("  ✓ Uebersicht.txt erstellt")
                except Exception as e:
                    self.log(f"  ✗ Übersicht fehlgeschlagen: {str(e)}")

                # Migration-Datei erstellen (immer)
                self.log("→ Erstelle Migration-Datei...")
                try:
                    self.create_migration_file(dest_root)
                    self.log("  ✓ migration.json erstellt")
                except Exception as e:
                    self.log(f"  ✗ Migration fehlgeschlagen: {str(e)}")

                # JSON-Export (optional, für APPLY-Tool)
                if self.export_json.get():
                    self.log("→ Erstelle zusätzlich APPLY-Export...")
                    try:
                        self.create_json_export(dest_root)
                        self.log("  ✓ apply_export.json erstellt")
                    except Exception as e:
                        self.log(f"  ✗ APPLY-Export fehlgeschlagen: {str(e)}")

                self.update_progress(1.0, "✓ Abgeschlossen!")
                self.log("=== Sammlung erfolgreich abgeschlossen ===")

                # Explorer öffnen
                if sys.platform == 'win32':
                    os.startfile(dest_root)
                    self.log(f"Explorer geöffnet: {dest_root}")
            else:
                self.update_progress(0, "Abgebrochen")
                self.log("=== Sammlung abgebrochen ===")

        except Exception as e:
            self.log(f"✗ FEHLER: {str(e)}")
            self.update_progress(0, "Fehler!")
        finally:
            self.is_running = False
            self.start_btn.configure(state="normal")
            self.stop_btn.configure(state="disabled")

    # === SAMMLUNGS-FUNKTIONEN ===

    def run_ps(self, script):
        """Führt PowerShell-Skript aus"""
        result = subprocess.run(
            ['powershell.exe', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command', script],
            capture_output=True,
            text=True,
            check=True
        )
        return result.stdout

    def collect_base_info(self, dest_root):
        """Basis-Informationen"""
        script = f"""
        $info = @(
            "Datum/Zeit:        $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')",
            "Computername:      $env:COMPUTERNAME",
            "Benutzername:      $env:USERNAME",
            "Benutzer-Domaene:  $env:USERDOMAIN",
            "Computer-Domaene:  $((Get-CimInstance Win32_ComputerSystem).Domain)",
            "Seriennummer:      $((Get-CimInstance Win32_BIOS).SerialNumber)"
        )
        $info | Out-File -FilePath '{dest_root / "Basisinfo.txt"}' -Encoding UTF8 -Force
        """
        self.run_ps(script)

    def collect_printers_info(self, dest_root):
        """Drucker-Informationen (ohne IPv6, mit Standarddrucker-Kennzeichnung)"""
        script = f"""
        $blacklist = @('^Fax$','^Microsoft XPS Document Writer$','^Microsoft Print to PDF$','^OneNote.*')
        $printers = Get-Printer | Where-Object {{
            $name = $_.Name
            -not ($blacklist | Where-Object {{ $name -match $_ }})
        }} | Select-Object Name, PortName, DriverName, Shared, Default

        $lines = @("=== DRUCKER-LISTE ===")
        $lines += ""

        $printers | ForEach-Object {{
            # Port bereinigen: IPv6 entfernen (alles nach [ oder mit : und Buchstaben)
            $port = $_.PortName
            if ($port -match ':' -and $port -match '[a-fA-F]') {{
                $port = "(Netzwerkdrucker)"
            }}

            # Standarddrucker kennzeichnen
            $defaultMark = ""
            if ($_.Default -eq $true) {{
                $defaultMark = " *** STANDARD ***"
            }}

            $lines += "Drucker:    $($_.Name)$defaultMark"
            $lines += "Port:       $port"
            $lines += "Treiber:    $($_.DriverName)"
            $lines += "Freigabe:   $(if($_.Shared){{'Ja'}}else{{'Nein'}})"
            $lines += "------------------------------------------------------------"
        }}
        $lines | Out-File -FilePath '{dest_root / "Drucker.txt"}' -Encoding UTF8 -Force
        """
        self.run_ps(script)

    def collect_network_info(self, dest_root):
        """Netzwerk-Informationen (nur aktive Adapter, ohne IPv6)"""
        script = f"""
        $lines = @("=== NETZWERK-KONFIGURATION ===")
        $lines += ""

        # Nur aktive Adapter (Status = Up)
        $adapters = Get-NetAdapter | Where-Object {{ $_.Status -eq 'Up' }} | Sort-Object ifIndex

        if ($adapters.Count -eq 0) {{
            $lines += "Keine aktiven Netzwerkadapter gefunden."
        }} else {{
            foreach ($a in $adapters) {{
                $cfg = Get-NetIPConfiguration -InterfaceIndex $a.ifIndex -ErrorAction SilentlyContinue
                $ipv4 = ($cfg.IPv4Address | ForEach-Object {{ $_.IPAddress }}) -join ", "
                $gw = ($cfg.IPv4DefaultGateway | ForEach-Object {{ $_.NextHop }}) -join ", "

                # DNS filtern: nur IPv4-Adressen (keine IPv6)
                $dnsAll = $cfg.DnsServer.ServerAddresses
                $dnsIPv4 = $dnsAll | Where-Object {{ $_ -match '^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$' }}
                $dns = $dnsIPv4 -join ", "

                $lines += "Adapter:  $($a.Name)"
                $lines += "Status:   $($a.Status)"
                $lines += "MAC:      $($a.MacAddress)"
                $lines += "IPv4:     $ipv4"
                $lines += "Gateway:  $gw"
                $lines += "DNS:      $dns"
                $lines += "------------------------------------------------------------"
            }}
        }}
        $lines | Out-File -FilePath '{dest_root / "Netzwerk.txt"}' -Encoding UTF8 -Force
        """
        self.run_ps(script)

    def collect_registry_export(self, dest_root):
        """Registry-Export"""
        output_file = dest_root / "albis.reg"
        subprocess.run([
            'reg.exe', 'export',
            'HKCU\\Software\\ALBIS',
            str(output_file),
            '/y'
        ], check=True, capture_output=True)

    def collect_albis_files(self, dest_root):
        """ALBIS-Dateien"""
        script = f"""
        $source = "C:\\CGM\\ALBISWIN"
        $dest = "{dest_root / 'ALBISWIN'}"

        if (Test-Path $source) {{
            New-Item -ItemType Directory -Path $dest -Force | Out-Null
            Get-ChildItem -Path $source -File | Copy-Item -Destination $dest -Force
            Write-Output "ALBIS-Dateien kopiert"
        }} else {{
            Write-Output "ALBIS-Pfad nicht gefunden"
        }}
        """
        self.run_ps(script)

    def collect_user_folders(self, dest_root):
        """Benutzerordner"""
        script = f"""
        $folders = @(
            @{{ name = 'Dokumente'; src = [Environment]::GetFolderPath('MyDocuments') }},
            @{{ name = 'Bilder'; src = [Environment]::GetFolderPath('MyPictures') }},
            @{{ name = 'Desktop'; src = [Environment]::GetFolderPath('Desktop') }}
        )

        foreach ($f in $folders) {{
            if (Test-Path $f.src) {{
                $dest = Join-Path '{dest_root}' $f.name
                New-Item -ItemType Directory -Path $dest -Force | Out-Null
                robocopy $f.src $dest /E /COPY:DAT /R:1 /W:1 /NP /NFL /NDL | Out-Null
                Write-Output "$($f.name) kopiert"
            }}
        }}
        """
        self.run_ps(script)

    def collect_screenshot_image(self, dest_root):
        """Screenshot"""
        script = f"""
        Add-Type -AssemblyName System.Windows.Forms
        Add-Type -AssemblyName System.Drawing

        $shell = New-Object -ComObject "Shell.Application"
        $shell.ToggleDesktop()
        Start-Sleep -Milliseconds 500

        $bounds = [System.Windows.Forms.Screen]::PrimaryScreen.Bounds
        $bmp = New-Object Drawing.Bitmap $bounds.Width, $bounds.Height
        $graphics = [Drawing.Graphics]::FromImage($bmp)
        $graphics.CopyFromScreen($bounds.Location, [Drawing.Point]::Empty, $bounds.Size)
        $bmp.Save('{dest_root / "desktop.png"}', [System.Drawing.Imaging.ImageFormat]::Png)
        $graphics.Dispose()
        $bmp.Dispose()

        $shell.ToggleDesktop()
        Write-Output "Screenshot erstellt"
        """
        self.run_ps(script)

    # ==================== NEUE FEATURES (v2.1) ====================

    def collect_mail_info(self, dest_root):
        """E-Mail-Client Erkennung (Outlook, Thunderbird) inkl. Konten"""
        script = f"""
        $lines = @("=== E-MAIL-CLIENTS ===")
        $lines += ""

        # Outlook prüfen
        $outlookPath = "$env:LOCALAPPDATA\\Microsoft\\Outlook"
        $outlookInstalled = Test-Path "HKLM:\\SOFTWARE\\Microsoft\\Office\\*\\Outlook" -ErrorAction SilentlyContinue
        if ($outlookInstalled -or (Test-Path $outlookPath)) {{
            $lines += "✓ Microsoft Outlook INSTALLIERT"

            # Outlook-Profile und Konten
            try {{
                $profiles = Get-ChildItem "HKCU:\\SOFTWARE\\Microsoft\\Office\\*\\Outlook\\Profiles" -ErrorAction SilentlyContinue
                if ($profiles) {{
                    $lines += "  Profile gefunden: $($profiles.Count)"
                }}

                # E-Mail-Adressen aus Registry
                $accounts = Get-ChildItem "HKCU:\\SOFTWARE\\Microsoft\\Office\\*\\Outlook\\Profiles\\*\\9375CFF0413111d3B88A00104B2A6676\\*" -ErrorAction SilentlyContinue
                foreach ($acc in $accounts) {{
                    $email = (Get-ItemProperty $acc.PSPath -ErrorAction SilentlyContinue).'Account Name'
                    if ($email) {{
                        $lines += "  → Konto: $email"
                    }}
                }}
            }} catch {{ }}
            $lines += ""
        }} else {{
            $lines += "✗ Microsoft Outlook nicht gefunden"
            $lines += ""
        }}

        # Thunderbird prüfen
        $tbPath = "$env:APPDATA\\Thunderbird\\Profiles"
        if (Test-Path $tbPath) {{
            $lines += "✓ Mozilla Thunderbird INSTALLIERT"

            # Thunderbird-Profile
            $tbProfiles = Get-ChildItem $tbPath -Directory -ErrorAction SilentlyContinue
            $lines += "  Profile gefunden: $($tbProfiles.Count)"

            # prefs.js nach E-Mail-Adressen durchsuchen
            foreach ($profile in $tbProfiles) {{
                $prefsFile = Join-Path $profile.FullName "prefs.js"
                if (Test-Path $prefsFile) {{
                    $content = Get-Content $prefsFile -Raw -ErrorAction SilentlyContinue
                    $matches = [regex]::Matches($content, 'mail\\.identity\\.id\\d+\\.useremail.*?"([^"]+)"')
                    foreach ($m in $matches) {{
                        $lines += "  → Konto: $($m.Groups[1].Value)"
                    }}
                }}
            }}
            $lines += ""
        }} else {{
            $lines += "✗ Mozilla Thunderbird nicht gefunden"
            $lines += ""
        }}

        $lines | Out-File -FilePath '{dest_root / "Email.txt"}' -Encoding UTF8 -Force
        """
        self.run_ps(script)

    def collect_office_info(self, dest_root):
        """MS Office Erkennung mit Version und Lizenzstatus"""
        script = f"""
        $lines = @("=== MICROSOFT OFFICE ===")
        $lines += ""

        # Office-Versionen in Registry suchen
        $officeKeys = @(
            "HKLM:\\SOFTWARE\\Microsoft\\Office\\ClickToRun\\Configuration",
            "HKLM:\\SOFTWARE\\Microsoft\\Office\\16.0\\Common\\InstallRoot",
            "HKLM:\\SOFTWARE\\Microsoft\\Office\\15.0\\Common\\InstallRoot",
            "HKLM:\\SOFTWARE\\Microsoft\\Office\\14.0\\Common\\InstallRoot"
        )

        $found = $false
        foreach ($key in $officeKeys) {{
            if (Test-Path $key) {{
                $props = Get-ItemProperty $key -ErrorAction SilentlyContinue
                if ($props) {{
                    $found = $true
                    $lines += "✓ Microsoft Office INSTALLIERT"

                    if ($props.ProductReleaseIds) {{
                        $lines += "  Produkt: $($props.ProductReleaseIds)"
                    }}
                    if ($props.VersionToReport) {{
                        $lines += "  Version: $($props.VersionToReport)"
                    }}
                    if ($props.Platform) {{
                        $lines += "  Plattform: $($props.Platform)"
                    }}
                    break
                }}
            }}
        }}

        if (-not $found) {{
            $lines += "✗ Microsoft Office nicht gefunden"
        }}

        # Lizenzstatus prüfen (cscript)
        $lines += ""
        $lines += "--- Lizenzstatus ---"
        try {{
            $osppPath = "C:\\Program Files\\Microsoft Office\\Office16\\ospp.vbs"
            if (-not (Test-Path $osppPath)) {{
                $osppPath = "C:\\Program Files (x86)\\Microsoft Office\\Office16\\ospp.vbs"
            }}
            if (Test-Path $osppPath) {{
                $license = cscript //nologo $osppPath /dstatus 2>$null | Select-String -Pattern "LICENSE|PRODUCT|STATUS"
                $lines += $license
            }} else {{
                $lines += "(Lizenzprüfung nicht möglich)"
            }}
        }} catch {{
            $lines += "(Lizenzprüfung fehlgeschlagen)"
        }}

        $lines | Out-File -FilePath '{dest_root / "Office.txt"}' -Encoding UTF8 -Force
        """
        self.run_ps(script)

    def collect_browser_favorites(self, dest_root):
        """Browser-Favoriten kopieren (Edge, Chrome, Firefox)"""
        script = f"""
        $destBrowser = '{dest_root / "Browser"}'
        New-Item -ItemType Directory -Path $destBrowser -Force | Out-Null

        $lines = @("=== BROWSER-FAVORITEN ===")
        $lines += ""

        # Microsoft Edge
        $edgePath = "$env:LOCALAPPDATA\\Microsoft\\Edge\\User Data\\Default\\Bookmarks"
        if (Test-Path $edgePath) {{
            Copy-Item $edgePath (Join-Path $destBrowser "Edge_Bookmarks.json") -Force
            $lines += "✓ Microsoft Edge Favoriten kopiert"
        }} else {{
            $lines += "✗ Microsoft Edge Favoriten nicht gefunden"
        }}

        # Google Chrome
        $chromePath = "$env:LOCALAPPDATA\\Google\\Chrome\\User Data\\Default\\Bookmarks"
        if (Test-Path $chromePath) {{
            Copy-Item $chromePath (Join-Path $destBrowser "Chrome_Bookmarks.json") -Force
            $lines += "✓ Google Chrome Favoriten kopiert"
        }} else {{
            $lines += "✗ Google Chrome Favoriten nicht gefunden"
        }}

        # Mozilla Firefox
        $ffPath = "$env:APPDATA\\Mozilla\\Firefox\\Profiles"
        if (Test-Path $ffPath) {{
            $ffProfiles = Get-ChildItem $ffPath -Directory | Where-Object {{ Test-Path (Join-Path $_.FullName "places.sqlite") }}
            if ($ffProfiles) {{
                foreach ($p in $ffProfiles) {{
                    $src = Join-Path $p.FullName "places.sqlite"
                    $dst = Join-Path $destBrowser "Firefox_$($p.Name)_places.sqlite"
                    Copy-Item $src $dst -Force
                }}
                $lines += "✓ Mozilla Firefox Favoriten kopiert ($($ffProfiles.Count) Profile)"
            }}
        }} else {{
            $lines += "✗ Mozilla Firefox nicht gefunden"
        }}

        $lines | Out-File -FilePath (Join-Path $destBrowser "INFO.txt") -Encoding UTF8 -Force
        """
        self.run_ps(script)

    def collect_autostart_info(self, dest_root):
        """Autostart-Programme erfassen"""
        script = f"""
        $lines = @("=== AUTOSTART-PROGRAMME ===")
        $lines += ""

        # Registry: HKCU Run
        $lines += "--- HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run ---"
        $hkcuRun = Get-ItemProperty "HKCU:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run" -ErrorAction SilentlyContinue
        if ($hkcuRun) {{
            $hkcuRun.PSObject.Properties | Where-Object {{ $_.Name -notlike "PS*" }} | ForEach-Object {{
                $lines += "  $($_.Name): $($_.Value)"
            }}
        }}
        $lines += ""

        # Registry: HKLM Run
        $lines += "--- HKLM\\Software\\Microsoft\\Windows\\CurrentVersion\\Run ---"
        $hklmRun = Get-ItemProperty "HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run" -ErrorAction SilentlyContinue
        if ($hklmRun) {{
            $hklmRun.PSObject.Properties | Where-Object {{ $_.Name -notlike "PS*" }} | ForEach-Object {{
                $lines += "  $($_.Name): $($_.Value)"
            }}
        }}
        $lines += ""

        # Startup-Ordner (Benutzer)
        $lines += "--- Startup-Ordner (Benutzer) ---"
        $startupUser = [Environment]::GetFolderPath('Startup')
        if (Test-Path $startupUser) {{
            Get-ChildItem $startupUser -File | ForEach-Object {{
                $lines += "  $($_.Name)"
            }}
        }}
        $lines += ""

        # Startup-Ordner (Alle Benutzer)
        $lines += "--- Startup-Ordner (Alle Benutzer) ---"
        $startupAll = "$env:ProgramData\\Microsoft\\Windows\\Start Menu\\Programs\\Startup"
        if (Test-Path $startupAll) {{
            Get-ChildItem $startupAll -File | ForEach-Object {{
                $lines += "  $($_.Name)"
            }}
        }}

        $lines | Out-File -FilePath '{dest_root / "Autostart.txt"}' -Encoding UTF8 -Force
        """
        self.run_ps(script)

    def collect_software_info(self, dest_root):
        """Software-Scan (CGM, Medizin, etc. via Whitelists)"""
        # Whitelists laden
        config_path = Path(__file__).parent.parent / "config"
        whitelists = {}

        for wl_file in ["wl_cgm-sw.txt", "wl_medizin-sw.txt", "wl_finanz-sw.txt", "wl_extern-sw.txt"]:
            wl_path = config_path / wl_file
            if wl_path.exists():
                with open(wl_path, 'r', encoding='utf-8') as f:
                    entries = [line.strip() for line in f if line.strip() and not line.startswith('#')]
                    whitelists[wl_file.replace('wl_', '').replace('-sw.txt', '')] = entries

        # PowerShell-Script für Software-Liste
        script = f"""
        $lines = @("=== INSTALLIERTE SOFTWARE ===")
        $lines += ""

        # Alle installierten Programme
        $software = @()
        $paths = @(
            "HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\*",
            "HKLM:\\SOFTWARE\\WOW6432Node\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\*",
            "HKCU:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\*"
        )

        foreach ($path in $paths) {{
            Get-ItemProperty $path -ErrorAction SilentlyContinue | Where-Object {{ $_.DisplayName }} | ForEach-Object {{
                $software += [PSCustomObject]@{{
                    Name = $_.DisplayName
                    Version = $_.DisplayVersion
                    Publisher = $_.Publisher
                }}
            }}
        }}

        $software = $software | Sort-Object Name -Unique

        # Ausgabe
        foreach ($s in $software) {{
            $lines += "$($s.Name) | $($s.Version) | $($s.Publisher)"
        }}

        $lines | Out-File -FilePath '{dest_root / "Software_Alle.txt"}' -Encoding UTF8 -Force
        """
        self.run_ps(script)

        # Whitelist-Abgleich in Python
        try:
            software_file = dest_root / "Software_Alle.txt"
            if software_file.exists():
                with open(software_file, 'r', encoding='utf-8') as f:
                    all_software = f.read()

                # Gefundene Software nach Kategorie
                found = {"cgm": [], "medizin": [], "finanz": [], "extern": []}

                for category, entries in whitelists.items():
                    for entry in entries:
                        if entry.lower() in all_software.lower():
                            found[category].append(entry)

                # Zusammenfassung schreiben
                summary = ["=== SOFTWARE-ZUSAMMENFASSUNG ===", ""]
                for cat, items in found.items():
                    summary.append(f"--- {cat.upper()} ---")
                    if items:
                        for item in items:
                            summary.append(f"  ✓ {item}")
                    else:
                        summary.append("  (keine gefunden)")
                    summary.append("")

                with open(dest_root / "Software_Zusammenfassung.txt", 'w', encoding='utf-8') as f:
                    f.write("\\n".join(summary))
        except Exception as e:
            self.log(f"  ⚠ Whitelist-Abgleich: {e}")

    def collect_scheduled_tasks(self, dest_root):
        """Aufgabenplanung exportieren"""
        script = f"""
        $lines = @("=== AUFGABENPLANUNG ===")
        $lines += ""

        # Benutzerdefinierte Tasks (nicht Microsoft)
        $tasks = Get-ScheduledTask | Where-Object {{
            $_.TaskPath -notlike "\\Microsoft*" -and
            $_.State -ne "Disabled"
        }} | Select-Object TaskName, TaskPath, State, @{{N='NextRun';E={{$_.Triggers | Select-Object -First 1}}}}

        if ($tasks) {{
            $lines += "Anzahl: $($tasks.Count)"
            $lines += ""
            foreach ($t in $tasks) {{
                $lines += "Task: $($t.TaskName)"
                $lines += "  Pfad: $($t.TaskPath)"
                $lines += "  Status: $($t.State)"
                $lines += "------------------------------------------------------------"
            }}
        }} else {{
            $lines += "(Keine benutzerdefinierten Tasks gefunden)"
        }}

        $lines | Out-File -FilePath '{dest_root / "Aufgabenplanung.txt"}' -Encoding UTF8 -Force
        """
        self.run_ps(script)

    def create_json_export(self, dest_root):
        """Erstellt JSON-Export für APPLY-Tool"""
        json_data = {
            "version": "2.0",
            "timestamp": datetime.now().isoformat(),
            "computer_info": {},
            "network": {"adapters": []},
            "printers": [],
            "notes": "Automatisch generiert von eXpletus COLLECT"
        }

        # Basis-Informationen lesen
        baseinfo_file = dest_root / "Basisinfo.txt"
        if baseinfo_file.exists():
            with open(baseinfo_file, 'r', encoding='utf-8') as f:
                content = f.read()
                for line in content.split('\n'):
                    if ':' in line:
                        key, value = line.split(':', 1)
                        key = key.strip()
                        value = value.strip()
                        if key == "Computername":
                            json_data["computer_info"]["hostname"] = value
                        elif key == "Benutzername":
                            json_data["computer_info"]["username"] = value
                        elif key == "Computer-Domaene":
                            json_data["computer_info"]["domain"] = value
                        elif key == "Seriennummer":
                            json_data["computer_info"]["serial_number"] = value

        # Netzwerk-Informationen lesen
        network_file = dest_root / "Netzwerk.txt"
        if network_file.exists():
            with open(network_file, 'r', encoding='utf-8') as f:
                content = f.read()
                adapters = content.split('------------------------------------------------------------')
                for adapter_text in adapters:
                    if not adapter_text.strip():
                        continue

                    adapter = {}
                    for line in adapter_text.split('\n'):
                        if ':' in line:
                            key, value = line.split(':', 1)
                            key = key.strip()
                            value = value.strip()
                            if key == "Adapter":
                                adapter["name"] = value
                            elif key == "MAC":
                                adapter["mac"] = value
                            elif key == "IPv4":
                                adapter["ipv4"] = value
                            elif key == "IPv6":
                                adapter["ipv6"] = value
                            elif key == "Gateway":
                                adapter["gateway"] = value
                            elif key == "DNS":
                                adapter["dns"] = value.split(", ") if value else []
                            elif key == "Status":
                                adapter["status"] = value

                    if adapter:
                        json_data["network"]["adapters"].append(adapter)

        # Drucker-Informationen lesen
        printer_file = dest_root / "Drucker.txt"
        if printer_file.exists():
            with open(printer_file, 'r', encoding='utf-8') as f:
                lines = f.readlines()
                for line in lines[1:]:  # Erste Zeile überspringen (Header)
                    if line.strip():
                        parts = line.strip().split('\t')
                        if len(parts) >= 5:
                            printer = {
                                "name": parts[0],
                                "port": parts[1],
                                "default": parts[2].lower() == 'true',
                                "shared": parts[3].lower() == 'true',
                                "driver": parts[4]
                            }
                            json_data["printers"].append(printer)

        # JSON speichern (für APPLY-Tool als apply_export.json)
        json_file = dest_root / "apply_export.json"
        with open(json_file, 'w', encoding='utf-8') as f:
            json.dump(json_data, f, indent=2, ensure_ascii=False)

    def create_overview(self, dest_root):
        """Erstellt eine übersichtliche Zusammenfassung aller gesammelten Daten"""
        lines = []
        lines.append("=" * 70)
        lines.append("  eXpletus COLLECT - ÜBERSICHT")
        lines.append("  " + datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
        lines.append("=" * 70)
        lines.append("")

        # Basis-Informationen
        baseinfo_file = dest_root / "Basisinfo.txt"
        if baseinfo_file.exists():
            lines.append(">>> SYSTEM <<<")
            with open(baseinfo_file, 'r', encoding='utf-8') as f:
                for line in f:
                    if line.strip():
                        lines.append("  " + line.strip())
            lines.append("")

        # Netzwerk (Kurzfassung)
        network_file = dest_root / "Netzwerk.txt"
        if network_file.exists():
            lines.append(">>> NETZWERK <<<")
            with open(network_file, 'r', encoding='utf-8') as f:
                content = f.read()
                for block in content.split('----'):
                    for line in block.split('\n'):
                        if line.strip() and 'Adapter:' in line:
                            lines.append("  " + line.strip())
                        elif line.strip() and 'IPv4:' in line:
                            lines.append("  " + line.strip())
                        elif line.strip() and 'DNS:' in line:
                            lines.append("  " + line.strip())
            lines.append("")

        # Drucker (Kurzfassung)
        printer_file = dest_root / "Drucker.txt"
        if printer_file.exists():
            lines.append(">>> DRUCKER <<<")
            with open(printer_file, 'r', encoding='utf-8') as f:
                for line in f:
                    if 'Drucker:' in line:
                        lines.append("  " + line.strip())
            lines.append("")

        # E-Mail
        email_file = dest_root / "Email.txt"
        if email_file.exists():
            lines.append(">>> E-MAIL <<<")
            with open(email_file, 'r', encoding='utf-8') as f:
                for line in f:
                    if line.strip() and ('✓' in line or '✗' in line or '→' in line):
                        lines.append("  " + line.strip())
            lines.append("")

        # Office
        office_file = dest_root / "Office.txt"
        if office_file.exists():
            lines.append(">>> MS OFFICE <<<")
            with open(office_file, 'r', encoding='utf-8') as f:
                for line in f:
                    if line.strip() and ('✓' in line or '✗' in line or 'Produkt:' in line or 'Version:' in line):
                        lines.append("  " + line.strip())
            lines.append("")

        # Software-Zusammenfassung
        software_file = dest_root / "Software_Zusammenfassung.txt"
        if software_file.exists():
            lines.append(">>> ERKANNTE SOFTWARE <<<")
            with open(software_file, 'r', encoding='utf-8') as f:
                for line in f:
                    if line.strip() and ('✓' in line or '---' in line):
                        lines.append("  " + line.strip())
            lines.append("")

        # Autostart (Anzahl)
        autostart_file = dest_root / "Autostart.txt"
        if autostart_file.exists():
            lines.append(">>> AUTOSTART <<<")
            with open(autostart_file, 'r', encoding='utf-8') as f:
                content = f.readlines()
                count = sum(1 for line in content if line.strip() and not line.startswith('---') and not line.startswith('==='))
                lines.append(f"  {count} Einträge gefunden (Details in Autostart.txt)")
            lines.append("")

        # Gesammelte Dateien
        lines.append(">>> GESAMMELTE DATEIEN <<<")
        for f in dest_root.iterdir():
            if f.is_file():
                size = f.stat().st_size
                size_str = f"{size/1024:.1f} KB" if size > 1024 else f"{size} B"
                lines.append(f"  {f.name} ({size_str})")
        for d in dest_root.iterdir():
            if d.is_dir():
                file_count = sum(1 for _ in d.rglob('*') if _.is_file())
                lines.append(f"  [{d.name}/] ({file_count} Dateien)")
        lines.append("")

        lines.append("=" * 70)
        lines.append("  Übersicht anzeigen: python src/overview_viewer.py <Pfad>")
        lines.append("=" * 70)

        # Speichern
        overview_file = dest_root / "Uebersicht.txt"
        with open(overview_file, 'w', encoding='utf-8') as f:
            f.write('\n'.join(lines))

    def create_migration_file(self, dest_root):
        """Erstellt eine umfassende Migration-Datei mit allen gesammelten Daten"""
        migration_data = {
            "version": "2.2",
            "created": datetime.now().isoformat(),
            "source": {
                "tool": "eXpletus COLLECT",
                "hostname": os.environ.get('COMPUTERNAME', 'UNKNOWN')
            },
            "system": {},
            "network": [],
            "printers": [],
            "email": {},
            "office": {},
            "software": {
                "all": [],
                "cgm": [],
                "medical": [],
                "finance": [],
                "other": []
            },
            "autostart": [],
            "browser": {
                "edge": False,
                "chrome": False,
                "firefox": False
            }
        }

        # Basis-Informationen
        baseinfo_file = dest_root / "Basisinfo.txt"
        if baseinfo_file.exists():
            with open(baseinfo_file, 'r', encoding='utf-8') as f:
                for line in f:
                    if ':' in line:
                        key, value = line.split(':', 1)
                        key = key.strip().lower().replace('-', '_').replace(' ', '_')
                        migration_data["system"][key] = value.strip()

        # Netzwerk
        network_file = dest_root / "Netzwerk.txt"
        if network_file.exists():
            with open(network_file, 'r', encoding='utf-8') as f:
                content = f.read()
                current_adapter = {}
                for line in content.split('\n'):
                    if 'Adapter:' in line:
                        if current_adapter:
                            migration_data["network"].append(current_adapter)
                        current_adapter = {"name": line.split(':', 1)[1].strip()}
                    elif ':' in line and current_adapter:
                        key, value = line.split(':', 1)
                        key = key.strip().lower()
                        current_adapter[key] = value.strip()
                if current_adapter:
                    migration_data["network"].append(current_adapter)

        # Drucker
        printer_file = dest_root / "Drucker.txt"
        if printer_file.exists():
            with open(printer_file, 'r', encoding='utf-8') as f:
                content = f.read()
                current_printer = {}
                for line in content.split('\n'):
                    if 'Drucker:' in line:
                        if current_printer:
                            migration_data["printers"].append(current_printer)
                        name = line.split(':', 1)[1].strip()
                        current_printer = {
                            "name": name.replace(' *** STANDARD ***', ''),
                            "default": '*** STANDARD ***' in name
                        }
                    elif ':' in line and current_printer and not line.startswith('---'):
                        key, value = line.split(':', 1)
                        key = key.strip().lower()
                        current_printer[key] = value.strip()
                if current_printer:
                    migration_data["printers"].append(current_printer)

        # E-Mail
        email_file = dest_root / "Email.txt"
        if email_file.exists():
            with open(email_file, 'r', encoding='utf-8') as f:
                content = f.read()
                migration_data["email"]["outlook_installed"] = '✓ Microsoft Outlook' in content
                migration_data["email"]["thunderbird_installed"] = '✓ Mozilla Thunderbird' in content
                # E-Mail-Adressen extrahieren
                import re
                emails = re.findall(r'→ Konto: (.+)', content)
                migration_data["email"]["accounts"] = emails

        # Office
        office_file = dest_root / "Office.txt"
        if office_file.exists():
            with open(office_file, 'r', encoding='utf-8') as f:
                content = f.read()
                migration_data["office"]["installed"] = '✓ Microsoft Office' in content
                for line in content.split('\n'):
                    if 'Produkt:' in line:
                        migration_data["office"]["product"] = line.split(':', 1)[1].strip()
                    elif 'Version:' in line:
                        migration_data["office"]["version"] = line.split(':', 1)[1].strip()

        # Software
        software_summary_file = dest_root / "Software_Zusammenfassung.txt"
        if software_summary_file.exists():
            with open(software_summary_file, 'r', encoding='utf-8') as f:
                content = f.read()
                current_category = None
                for line in content.split('\n'):
                    if '--- CGM ---' in line:
                        current_category = "cgm"
                    elif '--- MEDIZIN ---' in line:
                        current_category = "medical"
                    elif '--- FINANZ ---' in line:
                        current_category = "finance"
                    elif '--- EXTERN ---' in line:
                        current_category = "other"
                    elif '✓' in line and current_category:
                        sw_name = line.replace('✓', '').strip()
                        migration_data["software"][current_category].append(sw_name)

        # Alle Software
        software_all_file = dest_root / "Software_Alle.txt"
        if software_all_file.exists():
            with open(software_all_file, 'r', encoding='utf-8') as f:
                for line in f:
                    if '|' in line:
                        parts = line.split('|')
                        if len(parts) >= 2:
                            migration_data["software"]["all"].append({
                                "name": parts[0].strip(),
                                "version": parts[1].strip() if len(parts) > 1 else "",
                                "publisher": parts[2].strip() if len(parts) > 2 else ""
                            })

        # Autostart
        autostart_file = dest_root / "Autostart.txt"
        if autostart_file.exists():
            with open(autostart_file, 'r', encoding='utf-8') as f:
                for line in f:
                    if ':' in line and not line.startswith('---') and not line.startswith('==='):
                        parts = line.split(':', 1)
                        if len(parts) == 2:
                            migration_data["autostart"].append({
                                "name": parts[0].strip(),
                                "path": parts[1].strip()
                            })

        # Browser
        browser_dir = dest_root / "Browser"
        if browser_dir.exists():
            migration_data["browser"]["edge"] = (browser_dir / "Edge_Bookmarks.json").exists()
            migration_data["browser"]["chrome"] = (browser_dir / "Chrome_Bookmarks.json").exists()
            migration_data["browser"]["firefox"] = any(browser_dir.glob("Firefox_*.sqlite"))

        # Migration-Datei speichern
        migration_file = dest_root / "migration.json"
        with open(migration_file, 'w', encoding='utf-8') as f:
            json.dump(migration_data, f, indent=2, ensure_ascii=False)


def main():
    """Hauptfunktion"""
    # Starte GUI ohne Console-Ausgaben (außer bei Fehlern)
    try:
        app = CollectorGUI()
        app.mainloop()

    except ImportError as e:
        # Zeige Fehler als Messagebox falls tkinter verfügbar
        try:
            from tkinter import messagebox
            messagebox.showerror(
                "Fehlende Module",
                f"Benötigte Module nicht gefunden!\n\n{e}\n\nBitte führen Sie aus:\npip install customtkinter Pillow"
            )
        except:
            # Fallback auf Console
            print(f"FEHLER: Module fehlen - {e}")
            print("Lösung: pip install customtkinter Pillow")
        sys.exit(1)

    except Exception as e:
        # Zeige Fehler als Messagebox
        try:
            from tkinter import messagebox
            import traceback
            error_msg = f"Fehlertyp: {type(e).__name__}\n\nFehlermeldung: {e}\n\nStack Trace:\n{traceback.format_exc()}"
            messagebox.showerror("Fehler beim Starten", error_msg)
        except:
            # Fallback auf Console
            import traceback
            print(f"FEHLER: {e}")
            traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
