#!/usr/bin/env python3
"""
eXpletus COLLECT - Übersichts-Viewer
Light-GUI zum Anzeigen der gesammelten Daten (nur Lesemodus)
"""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import json
from pathlib import Path
import sys


class OverviewViewer(tk.Tk):
    def __init__(self, path=None):
        super().__init__()

        self.title("eXpletus COLLECT - Übersicht")
        self.geometry("800x600")
        self.configure(bg="#2b2b2b")

        # Style
        style = ttk.Style()
        style.theme_use('clam')
        style.configure("TNotebook", background="#2b2b2b")
        style.configure("TNotebook.Tab", padding=[10, 5], font=('Arial', 10))
        style.configure("TFrame", background="#2b2b2b")

        self.create_ui()

        # Daten laden falls Pfad übergeben
        if path:
            self.load_data(Path(path))

    def create_ui(self):
        """Erstellt die Benutzeroberfläche"""
        # Header
        header = tk.Frame(self, bg="#1e1e1e", height=50)
        header.pack(fill="x")
        header.pack_propagate(False)

        tk.Label(
            header,
            text="eXpletus COLLECT - Übersicht",
            font=("Arial", 14, "bold"),
            fg="white",
            bg="#1e1e1e"
        ).pack(side="left", padx=10, pady=10)

        tk.Button(
            header,
            text="Ordner öffnen",
            command=self.open_folder,
            bg="#3c3c3c",
            fg="white",
            relief="flat",
            padx=15
        ).pack(side="right", padx=10, pady=10)

        # Notebook (Tabs)
        self.notebook = ttk.Notebook(self)
        self.notebook.pack(fill="both", expand=True, padx=10, pady=10)

        # Tab: Übersicht
        self.overview_frame = tk.Frame(self.notebook, bg="#2b2b2b")
        self.notebook.add(self.overview_frame, text="Übersicht")

        self.overview_text = tk.Text(
            self.overview_frame,
            font=("Consolas", 10),
            bg="#1e1e1e",
            fg="#d4d4d4",
            relief="flat",
            padx=10,
            pady=10,
            state="disabled"
        )
        self.overview_text.pack(fill="both", expand=True)

        # Tab: System
        self.system_frame = tk.Frame(self.notebook, bg="#2b2b2b")
        self.notebook.add(self.system_frame, text="System")

        self.system_tree = self.create_treeview(self.system_frame)

        # Tab: Netzwerk
        self.network_frame = tk.Frame(self.notebook, bg="#2b2b2b")
        self.notebook.add(self.network_frame, text="Netzwerk")

        self.network_tree = self.create_treeview(self.network_frame)

        # Tab: Drucker
        self.printer_frame = tk.Frame(self.notebook, bg="#2b2b2b")
        self.notebook.add(self.printer_frame, text="Drucker")

        self.printer_tree = self.create_treeview(self.printer_frame)

        # Tab: Software
        self.software_frame = tk.Frame(self.notebook, bg="#2b2b2b")
        self.notebook.add(self.software_frame, text="Software")

        self.software_tree = self.create_treeview(self.software_frame)

        # Tab: JSON (Raw)
        self.json_frame = tk.Frame(self.notebook, bg="#2b2b2b")
        self.notebook.add(self.json_frame, text="Migration JSON")

        self.json_text = tk.Text(
            self.json_frame,
            font=("Consolas", 9),
            bg="#1e1e1e",
            fg="#d4d4d4",
            relief="flat",
            padx=10,
            pady=10,
            state="disabled"
        )
        self.json_text.pack(fill="both", expand=True)

        # Statusbar
        self.status = tk.Label(
            self,
            text="Kein Ordner geladen - Klicken Sie auf 'Ordner öffnen'",
            bg="#1e1e1e",
            fg="#888888",
            anchor="w",
            padx=10
        )
        self.status.pack(fill="x", side="bottom")

    def create_treeview(self, parent):
        """Erstellt einen Treeview mit Scrollbar"""
        container = tk.Frame(parent, bg="#2b2b2b")
        container.pack(fill="both", expand=True)

        tree = ttk.Treeview(container, columns=("value",), show="tree headings")
        tree.heading("#0", text="Eigenschaft", anchor="w")
        tree.heading("value", text="Wert", anchor="w")
        tree.column("#0", width=250)
        tree.column("value", width=500)

        scrollbar = ttk.Scrollbar(container, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=scrollbar.set)

        tree.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        return tree

    def open_folder(self):
        """Öffnet einen Ordner mit gesammelten Daten"""
        folder = filedialog.askdirectory(title="Sammlung auswählen")
        if folder:
            self.load_data(Path(folder))

    def load_data(self, path):
        """Lädt Daten aus dem angegebenen Ordner"""
        if not path.exists():
            messagebox.showerror("Fehler", f"Ordner nicht gefunden: {path}")
            return

        self.status.configure(text=f"Geladen: {path}")

        # Übersicht laden
        overview_file = path / "Uebersicht.txt"
        if overview_file.exists():
            self.overview_text.configure(state="normal")
            self.overview_text.delete("1.0", "end")
            with open(overview_file, 'r', encoding='utf-8') as f:
                self.overview_text.insert("1.0", f.read())
            self.overview_text.configure(state="disabled")

        # Migration JSON laden
        migration_file = path / "migration.json"
        if migration_file.exists():
            with open(migration_file, 'r', encoding='utf-8') as f:
                migration_data = json.load(f)

            # JSON Tab
            self.json_text.configure(state="normal")
            self.json_text.delete("1.0", "end")
            self.json_text.insert("1.0", json.dumps(migration_data, indent=2, ensure_ascii=False))
            self.json_text.configure(state="disabled")

            # System Tab
            self.system_tree.delete(*self.system_tree.get_children())
            if "system" in migration_data:
                for key, value in migration_data["system"].items():
                    self.system_tree.insert("", "end", text=key, values=(value,))

            if "source" in migration_data:
                for key, value in migration_data["source"].items():
                    self.system_tree.insert("", "end", text=f"source.{key}", values=(value,))

            # Netzwerk Tab
            self.network_tree.delete(*self.network_tree.get_children())
            if "network" in migration_data:
                for i, adapter in enumerate(migration_data["network"]):
                    parent = self.network_tree.insert("", "end", text=f"Adapter {i+1}: {adapter.get('name', 'Unbekannt')}")
                    for key, value in adapter.items():
                        if key != "name":
                            self.network_tree.insert(parent, "end", text=key, values=(value,))

            # Drucker Tab
            self.printer_tree.delete(*self.printer_tree.get_children())
            if "printers" in migration_data:
                for printer in migration_data["printers"]:
                    name = printer.get("name", "Unbekannt")
                    if printer.get("default"):
                        name += " (Standard)"
                    parent = self.printer_tree.insert("", "end", text=name)
                    for key, value in printer.items():
                        if key not in ("name", "default"):
                            self.printer_tree.insert(parent, "end", text=key, values=(value,))

            # Software Tab
            self.software_tree.delete(*self.software_tree.get_children())
            if "software" in migration_data:
                sw = migration_data["software"]

                # Kategorien
                for cat_name, cat_label in [("cgm", "CGM Software"), ("medical", "Medizin"), ("finance", "Finanzen"), ("other", "Sonstige")]:
                    if sw.get(cat_name):
                        parent = self.software_tree.insert("", "end", text=cat_label)
                        for item in sw[cat_name]:
                            self.software_tree.insert(parent, "end", text=item)

                # Alle Software (begrenzt auf 50)
                if sw.get("all"):
                    parent = self.software_tree.insert("", "end", text=f"Alle ({len(sw['all'])} Programme)")
                    for item in sw["all"][:50]:
                        name = item.get("name", "")
                        version = item.get("version", "")
                        self.software_tree.insert(parent, "end", text=name, values=(version,))
                    if len(sw["all"]) > 50:
                        self.software_tree.insert(parent, "end", text="... und mehr", values=(f"+{len(sw['all'])-50}",))

            # E-Mail und Office Info
            if "email" in migration_data:
                email = migration_data["email"]
                email_parent = self.system_tree.insert("", "end", text="E-Mail")
                if email.get("outlook_installed"):
                    self.system_tree.insert(email_parent, "end", text="Outlook", values=("Installiert",))
                if email.get("thunderbird_installed"):
                    self.system_tree.insert(email_parent, "end", text="Thunderbird", values=("Installiert",))
                for acc in email.get("accounts", []):
                    self.system_tree.insert(email_parent, "end", text="Konto", values=(acc,))

            if "office" in migration_data:
                office = migration_data["office"]
                if office.get("installed"):
                    office_parent = self.system_tree.insert("", "end", text="MS Office")
                    if office.get("product"):
                        self.system_tree.insert(office_parent, "end", text="Produkt", values=(office["product"],))
                    if office.get("version"):
                        self.system_tree.insert(office_parent, "end", text="Version", values=(office["version"],))


def main():
    if len(sys.argv) > 1:
        path = sys.argv[1]
    else:
        path = None

    app = OverviewViewer(path)
    app.mainloop()


if __name__ == "__main__":
    main()
